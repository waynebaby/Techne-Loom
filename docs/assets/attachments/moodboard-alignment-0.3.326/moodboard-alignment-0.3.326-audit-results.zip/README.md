# Moodboard Alignment .NET SO 0.3.326 Audit Bundle

## Scope

This bundle contains the local Windows x64 business run for Moodboard Alignment using the published SkillOrchestrator runtime `0.3.326`, together with its compile audit and resulting project files.

The source governance snapshot `d941cec` recorded the public business run as pending. This execution happened later in a local environment; the audit directory was not committed to the Moodboard governance repository.

## Inventory

- 96 run-audit files across 20 step snapshots. Four selected `workflow.mermaid.md` and `workflow.json` files are supplied separately beside this ZIP.
- 6 compile-audit files from `step-0001-compiled`.
- 19 workflow inputs and event records: 16 `resume-*.json` payloads, `run-context.json`, `workflow.json.events.jsonl`, and its metadata file. The current root `workflow.json` and empty lock file are omitted; the final-step status snapshot is a separate attachment.
- 6 project outputs: `data.json`, two CK2 HTML views, and three final HTML views.
- 34 workflow-history records and 34 event-log records; the final business state reached `state.done`.

Each run-audit snapshot contains `workflow.analysis.json`, `workflow.dataflow.json`, `workflow.html`, `workflow.json`, and `workflow.mermaid.md`. Compile output additionally includes `workflow.compile-feedback.json`.

The ZIP includes the original brief, workflow/event records, resume payloads, data, and HTML results. Absolute local paths and project content may appear in those records. No image assets were generated; image references use placeholders. No audio files were generated.

## Separate Attachments

The following four selected audit artifacts are linked beside this ZIP and are intentionally excluded from it:

- `step-0009-blocked-WaitResume.mermaid.md`
- `step-0009-blocked-WaitResume.workflow.json`
- `step-0034-completed.mermaid.md`
- `step-0034-completed.workflow.json`

The `.lock` files are coordination markers, not audit artifacts, and are excluded. Counts refer to files in audit step folders only.
